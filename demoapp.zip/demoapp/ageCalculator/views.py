from django.shortcuts import render
from datetime import date, datetime

# Create your views here.
def index(request):
    context={}
    if request.method =="POST":
        date_of_birth = request.POST['date']
        date_of_birth = datetime.strptime(date_of_birth, '%Y-%m-%d').date()
        today = date.today()
       
        age = today.year - date_of_birth.year -((today.month, today.day)<(date_of_birth.month,date_of_birth.day))
        print(age)
        context = {
            "age":age
        }
    return render(request, 'index.html',context)